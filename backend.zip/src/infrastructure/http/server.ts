import express from 'express';
import bodyParser from 'body-parser';
import cookieParser from 'cookie-parser';
import cors from 'cors'; 
import { errorMiddleware } from '../../interface/http/middleware/error';
import { authenticationRouter } from '../../interface/http/api/authentication/router';
import { userRouter } from '../../interface/http/api/user/router';
import { okupasiRouter } from '../../interface/http/api/okupasi/router';
import { sekolahRouter } from '../../interface/http/api/sekolah/router';

export const initServer = () => {
  const app = express();

  // middleware CORS
  app.use(cors({
    origin: 'http://localhost:5173',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true  // Mengizinkan pengiriman kredensial seperti cookie
  }));
  // middleware CORS

  app.get('', function(req, res) {
    res.status(200).json({ message: 'Welcome to Assessment Okupasi API' });
  });

  app.use(bodyParser.json(), cookieParser());
  app.use(
    '/api/v1',
    authenticationRouter(),
    userRouter(),
    okupasiRouter(),
    sekolahRouter(),
  );

  // Endpoint Logout
  app.post('/api/v1/user/logout', (req, res) => {
    res.clearCookie('authToken', {
      path: '/',
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',  // hanya jika menggunakan HTTPS
      sameSite: 'strict'
    });
    res.status(200).json({ message: 'Logout successful' });
  });

  // Endpoint Check Auth
  app.get('/api/v1/user/checkAuth', (req, res) => {
    const token = req.cookies.authToken;
    if (token) {
      res.status(200).json({ authenticated: true });
    } else {
      res.status(401).json({ authenticated: false });
    }
  });

  app.use(errorMiddleware);

  return app;
};
